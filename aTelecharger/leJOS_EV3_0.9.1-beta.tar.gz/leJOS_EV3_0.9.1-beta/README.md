leJOS EV3 0.9.1 release
=======================

See the [Wiki](https://sourceforge.net/p/lejos/wiki/Getting%20started%20with%20leJOS%20EV3/) for how to install leJOS EV3.

On Windows, you should use the .exe installer. This includes everything including sample programs and development source, but installation of these is optional. You should uninstall previous versions of leJOS EV3 earlier than 0.9.0 before installing this version, as on 64-bit machines, the installer may not automatically do this. There is an optional win32.zip distribution, if the .exe distribution is not appropriate for any reason.

On Linux and MAC OSX, you should use the beta.tar.gz distribution. The development source is in a separate .source.tar.gz file, and the sample programs in a .samples.zip file.

